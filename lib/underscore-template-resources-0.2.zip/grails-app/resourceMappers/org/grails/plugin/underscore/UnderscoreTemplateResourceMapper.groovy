package org.grails.plugin.underscore

import org.codehaus.groovy.grails.plugins.support.aware.GrailsApplicationAware
import org.codehaus.groovy.grails.commons.GrailsApplication
import org.grails.plugin.resource.ResourceMeta
import org.grails.plugin.resource.mapper.MapperPhase


class UnderscoreTemplateResourceMapper implements GrailsApplicationAware {

    GrailsApplication grailsApplication

    def phase = MapperPhase.GENERATION

    static defaultIncludes = ['**/*.tpl']

    def map(ResourceMeta resource, config) {
        def processedFile = resource.processedFile
        def
        boolean fileAlreadyProcessed = processedFile.getAbsolutePath().indexOf(".js") == processedFile.getAbsolutePath().length() - 3;

        if(!fileAlreadyProcessed){
            def processedFileText = processedFile.text
            processedFileText = processedFileText.replace('\r\n', '\\n').replace('\n', '\\n').replace('"', '\\"')
            def filePath = processedFile.toString().replace('\\', '/')
            def contextFilePath = filePath

            int viewsIndex = contextFilePath.indexOf('/views/')
            int grailsResourceIndex = contextFilePath.indexOf('/grails-resources/')
            if (viewsIndex > 0) {
                contextFilePath = contextFilePath.substring(viewsIndex + 7)
            }
            else if (grailsResourceIndex > 0) {
                contextFilePath = contextFilePath.substring(grailsResourceIndex + 18)
            }
            else if (contextFilePath.charAt(0) == '/') {
                contextFilePath = contextFilePath.substring(1)
            }

            contextFilePath = contextFilePath.replace(' ', '')
            def context = contextFilePath.substring(0, contextFilePath.lastIndexOf('/')).replace('/', '.')
            def name = contextFilePath.substring(contextFilePath.lastIndexOf('/') + 1, contextFilePath.lastIndexOf('.'))
            name = (name.charAt(0).toLowerCase() as String) + name.substring(1)

            File target = new File(generateCompiledFileFromOriginal(filePath))
            String output = "GetContext('Gryphon.templates' + ('$context' ? '.' + '$context' : '')).$name = \"$processedFileText\";"
            target.write output

            resource.processedFile = target
            resource.sourceUrlExtension = 'js'
            resource.contentType = 'text/javascript'
        }

        resource.updateActualUrlFromProcessedFile()
    }

    private String generateCompiledFileFromOriginal(String original) {
        original.replaceAll(/(?i)\.tpl/, '_tpl.js')
    }

    private File getOriginalFileSystemFile(String sourcePath) {
        grailsApplication.parentContext.getResource(sourcePath).file
    }

    void setGrailsApplication(GrailsApplication grailsApplication) {
        this.grailsApplication = grailsApplication
    }
}